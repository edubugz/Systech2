package com.BugzTests;

import java.io.IOException;

public interface Register {
    public void register() throws IOException;
}
